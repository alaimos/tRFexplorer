library(testthat)
library(Glimma)

test_check("Glimma")
